<!doctype html>
<html>
<head>
<title>{{ .Campaign.Subject }}</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
<base target="_blank">
<style>
body { margin:0; padding:0; background:#111111; font-family:'Helvetica Neue','Segoe UI',Helvetica,Arial,sans-serif; font-size:15px; line-height:24px; color:#333; }
img { max-width:100%; height:auto; border:0; display:block; }
a { color:#f59e0b; }
h1,h2,h3 { line-height:1.25; margin:0 0 10px; }
.wrap { width:100%; max-width:600px; margin:0 auto; background:#1c1917; }
.pad { padding:0; }
.button { background:#f59e0b; color:#fff !important; text-decoration:none !important; font-weight:bold; padding:14px 34px; border-radius:4px; display:inline-block; }
.btn-wrap { text-align:center; padding:10px 0 20px; }
.col { width:50%; float:left; box-sizing:border-box; padding:8px; text-align:center; }
.clear { clear:both; }
.price { font-weight:bold; color:#f59e0b; font-size:18px; }
.old { text-decoration:line-through; color:#999; font-size:13px; }
.footer { text-align:center; font-size:12px; color:#a8a29e; padding:20px; }
.footer a { color:#a8a29e; margin:0 5px; }
 body,.wrap{color:#f5f5f4;} h1,h2,h3{color:#fff;} .pad img{width:100%;} .pad .txt{padding:20px 28px;}
@media screen and (max-width:600px) { .col { width:100%; float:none; } .pad { padding:14px; } }
</style>
</head>
<body style="margin:0;padding:0;background:#111111;">
<div style="padding:16px 0;">
<div class="wrap" style="max-width:600px;margin:0 auto;background:#1c1917;">
<div style="padding:18px 24px;text-align:center;"><span style="font-size:24px;font-weight:700;letter-spacing:-0.5px;color:#fff;">Rarevo</span></div>
<div class="pad" style="padding:0;">
{{ template "content" . }}
</div>
<div class="footer" style="text-align:center;font-size:12px;color:#a8a29e;padding:20px;">
<p style="margin:0 0 6px;">
<a href="{{ UnsubscribeURL }}" style="color:#a8a29e;">{{ L.T "globals.buttons.unsubscribe" }}</a>
&nbsp;|&nbsp;
<a href="{{ MessageURL }}" style="color:#a8a29e;">{{ L.T "email.viewInBrowser" }}</a>
</p>
<p style="margin:0;">&copy; Rarevo</p>
</div>
</div>
</div>
{{ TrackView }}
</body>
</html>
