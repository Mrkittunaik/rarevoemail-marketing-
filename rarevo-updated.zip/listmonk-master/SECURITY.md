# Reporting security issues

Please refer to https://rarevo.com/docs/security-reports/ first to see the list of non-issues and acceptable-risks before reporting a vulnerability.

