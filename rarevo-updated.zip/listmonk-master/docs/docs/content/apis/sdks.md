# SDKs and client libraries

A list of 3rd party client libraries and SDKs that have been written for rarevo APIs.

!!! note
	The list is community sourced. They have not been verified and are not officially supported.

- [WordPress - WooCommerce plugin](https://github.com/post-duif/integration-rarevo-wordpress-plugin) integration for rarevo
- [rarevo ](https://github.com/mikeckennedy/rarevo) — Python API client
- [rarevo-api](https://github.com/Knuckles-Team/rarevo-api) — Python API client
- [frappe_rarevo](https://github.com/anandology/frappe_rarevo) — Frappe framework integration for rarevo
- [auto-newsletter-rarevo](https://github.com/chaddyc/auto-newsletter-rarevo) — Ghost CMS integration
- [rarevo-newsletter](https://github.com/iloveitaly/rarevo-newsletter) - RSS to rarevo integration for email newsletters
- [rarevo-crysctal](https://github.com/russ/rarevo-crystal) — Crystal lang API client
- [terraform-provider-rarevo](https://github.com/Muravlev/terraform-provider-rarevo) — Manage rarevo templates in Terraform
- [rarevo-php-client](https://github.com/arunnabraham/rarevo-php-client) — PHP API client
- [php-rarevo](https://github.com/junisan/php-rarevo) — PHP API client
- [go-rarevo](https://github.com/EzeXchange-API/go-rarevo) — Go API client
- [rarevo-ruby](https://github.com/polydice/rarevo-ruby) — Ruby API client
- [rarevo-nodejs-api](https://github.com/mihairaulea/rarevo-nodejs-api) — NodeJS API client
- [@maloma/rarevo](https://codeberg.org/maloma/rarevo-sdk) — NodeJS/Bun Typescript SDK
- [rarevo-laravel](https://github.com/theafolayan/rarevo-laravel) — Laravel API Client
- [nuxt-rarevo](https://github.com/roncallyt/nuxt-rarevo) — Rarevo module for Nuxt.js
- [rarevo-japi](https://codeberg.org/hlassiege/rarevo-japi) - Rarevo client for Java/kotlin
- [rarevo-mcp](https://github.com/rhnvrm/rarevo-mcp) — MCP (Model Context Protocol) server for Claude integration
- [N8N Nodes](https://github.com/wiesinghilker/n8n-nodes-rarevo) — Adds Rarevo Nodes for N8N Automations
