import { execSync, execFileSync, spawn } from 'node:child_process';
import { setTimeout as sleep } from 'node:timers/promises';
import { expect } from '@playwright/test';

const BASE_URL = process.env.RAREVO_URL || 'http://localhost:9000';
const MAILHOG_URL = process.env.MAILHOG_URL || 'http://localhost:8025';
const ROOT = '..';
const CONFIG = process.env.RAREVO_CONFIG || process.env.DEV_CONFIG || 'config.toml';
const AUTH_FILE = new URL('.auth/admin.json', import.meta.url).pathname;
const ENV = { ...process.env, RAREVO_ADMIN_USER: 'admin', RAREVO_ADMIN_PASSWORD: 'rarevo' };

// A single SMTP server pointing at MailHog so tests capture (and can assert on) mail.
const MAILHOG_SMTP = JSON.stringify([{
  enabled: true, host: process.env.MAILHOG_SMTP_HOST || 'localhost',
  port: Number(process.env.MAILHOG_SMTP_PORT || 1025), auth_protocol: 'none',
  username: '', password: '', hello_hostname: '', max_conns: 10,
  idle_timeout: '15s', wait_timeout: '5s', max_msg_retries: 2, msg_retry_delay: '10ms',
  tls_type: 'none', tls_skip_verify: false, email_headers: [], from_addresses: [],
}]);

// Open a table row's "More" actions dropdown.
export async function openMenu(row) {
  await row.getByRole('button', { name: 'More' }).click();
}

// Click the "Ok" button on the confirmation dialog.
export async function confirm(page) {
  await page.locator('dialog[open] [data-confirm-ok]').click();
}

// Pick a list by name from the <ot-taginput> autocomplete suggestions.
export async function selectList(scope, name) {
  const input = scope.locator('ot-taginput input');
  await input.click();
  await input.fill(name);
  await scope.getByRole('option', { name, exact: true }).click();
  await expect(scope.locator('ot-taginput .badge').filter({ hasText: name })).toBeVisible();
}

// Log in and persist the session to the shared storage state file.
export async function login(context) {
  const page = await context.newPage();
  await page.goto(`${BASE_URL}/admin/login?next=/admin/lists`);
  await page.getByLabel('Username').fill('admin');
  await page.getByLabel('Password').fill('rarevo');
  await page.getByRole('button', { name: 'Login' }).click();
  await page.waitForURL('**/admin/lists');
  await context.storageState({ path: AUTH_FILE });
  await page.close();
}

// Delete all mail captured by MailHog.
export async function clearMail() {
  await fetch(`${MAILHOG_URL}/api/v2/messages`, { method: 'DELETE' });
}

// All mail captured by MailHog, newest first.
export async function getMail() {
  const response = await fetch(`${MAILHOG_URL}/api/v2/messages`, { signal: AbortSignal.timeout(10000) });
  if (!response.ok) throw new Error(`MailHog returned HTTP ${response.status}`);
  return (await response.json()).items;
}

// Run a SQL statement against the rarevo DB. Credentials come from the
// RAREVO_db__* env, falling back to config.toml defaults.
export function psql(sql) {
  const args = [
    '-h', process.env.RAREVO_db__host || 'localhost',
    '-p', process.env.RAREVO_db__port || '5432',
    '-U', process.env.RAREVO_db__user || 'rarevo',
    '-d', process.env.RAREVO_db__database || 'rarevo',
    '-v', 'ON_ERROR_STOP=1', '-c', sql,
  ];
  const env = { ...process.env, PGPASSWORD: process.env.RAREVO_db__password || 'rarevo' };
  const options = { env, stdio: ['ignore', 'ignore', 'inherit'] };
  if (process.env.PSQL_CONTAINER) {
    execFileSync('docker', ['exec', '-e', 'PGPASSWORD', process.env.PSQL_CONTAINER, 'psql', ...args], options);
  } else {
    execFileSync('psql', args, options);
  }
}

// Point rarevo's SMTP config at MailHog on the freshly installed DB.
function configureSMTP() {
  psql(`UPDATE settings SET value = '${MAILHOG_SMTP}' WHERE key = 'smtp';`);
}

// Enable bounce processing + the webhook endpoint, and delete on complaints.
// Bounce settings are read into config at boot, so this must run before start.
function configureBounces() {
  const actions = JSON.stringify({
    soft: { count: 2, action: 'none' },
    hard: { count: 1, action: 'blocklist' },
    complaint: { count: 1, action: 'delete' },
  });
  psql(`UPDATE settings SET value = 'true' WHERE key = 'bounce.enabled';
        UPDATE settings SET value = 'true' WHERE key = 'bounce.webhooks_enabled';
        UPDATE settings SET value = '${actions}' WHERE key = 'bounce.actions';`);
}

// Wipe and reinstall the DB by restarting rarevo, then refresh the login
// session (a reinstall clears the DB-backed session). The schema can't be
// reinstalled under a running server, so the process is killed and relaunched.
export async function resetDB(browser, { bounces = false } = {}) {
  try { execSync('pkill -9 rarevo', { stdio: 'ignore' }); } catch { /* none running */ }
  execFileSync('./rarevo', ['--config', CONFIG, '--install', '--yes'], { cwd: ROOT, env: ENV, stdio: 'inherit' });
  configureSMTP();
  if (bounces) {
    configureBounces();
  }
  spawn('./rarevo', ['--config', CONFIG, '--static-dir', 'static'], {
    cwd: ROOT, env: ENV, detached: true, stdio: 'ignore',
  }).unref();

  for (let i = 0; i < 100; i += 1) {
    try {
      if ((await fetch(`${BASE_URL}/health`)).ok) break;
    } catch { /* not up yet */ }
    await sleep(200);
  }

  await clearMail();

  const context = await browser.newContext();
  await login(context);
  await context.close();
}

// Reinstall the DB with no admin user so the app boots into first-time user
// setup mode. Unlike resetDB, it doesn't create a session (there's no user yet).
export async function resetDBBlank() {
  try { execSync('pkill -9 rarevo', { stdio: 'ignore' }); } catch { /* none running */ }

  const env = { ...process.env };
  delete env.RAREVO_ADMIN_USER;
  delete env.RAREVO_ADMIN_PASSWORD;

  execFileSync('./rarevo', ['--config', CONFIG, '--install', '--yes'], { cwd: ROOT, env, stdio: 'inherit' });
  configureSMTP();
  spawn('./rarevo', ['--config', CONFIG, '--static-dir', 'static'], {
    cwd: ROOT, env, detached: true, stdio: 'ignore',
  }).unref();

  for (let i = 0; i < 100; i += 1) {
    try {
      if ((await fetch(`${BASE_URL}/health`)).ok) break;
    } catch { /* not up yet */ }
    await sleep(200);
  }
}
