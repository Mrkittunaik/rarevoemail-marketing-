module github.com/rarevo/rarevo

go 1.27.3

require (
	github.com/Masterminds/sprig/v3 v3.3.0
	github.com/altcha-org/altcha-lib-go/v2 v2.4.1
	github.com/coreos/go-oidc/v3 v3.21.0
	github.com/disintegration/imaging v1.6.2
	github.com/emersion/go-message v0.18.2
	github.com/gdgvda/cron v0.7.0
	github.com/gofrs/uuid/v5 v5.5.1
	github.com/gorilla/feeds v1.2.0
	github.com/jmoiron/sqlx v1.4.0
	github.com/knadh/go-pop3 v1.0.2
	github.com/knadh/goyesql/v2 v2.2.0
	github.com/knadh/koanf/maps v0.1.3
	github.com/knadh/koanf/parsers/json v1.0.1
	github.com/knadh/koanf/parsers/toml v0.1.0
	github.com/knadh/koanf/providers/confmap v1.0.1
	github.com/knadh/koanf/providers/env v1.1.0
	github.com/knadh/koanf/providers/file v1.2.1
	github.com/knadh/koanf/providers/posflag v1.0.2
	github.com/knadh/koanf/providers/rawbytes v1.0.1
	github.com/knadh/koanf/v2 v2.4.1
	github.com/knadh/paginator/v2 v2.0.3
	github.com/knadh/smtppool/v2 v2.3.2
	github.com/knadh/stuffbin v1.3.0
	github.com/labstack/echo/v5 v5.4.2
	github.com/lib/pq v1.12.3
	github.com/paulbellamy/ratecounter v0.2.0
	github.com/pquerna/otp v1.5.0
	github.com/rhnvrm/simples3 v0.11.1
	github.com/spf13/pflag v1.0.10
	github.com/yuin/goldmark v1.8.6
	github.com/zerodha/easyjson v1.0.1
	github.com/zerodha/simplesessions/stores/postgres/v3 v3.0.0
	github.com/zerodha/simplesessions/v3 v3.0.0
	golang.org/x/mod v0.42.0
	golang.org/x/oauth2 v0.37.0
	golang.org/x/text v0.43.0
	gopkg.in/volatiletech/null.v6 v6.0.0-20170828023728-0bef4e07ae1b
)

require (
	dario.cat/mergo v1.0.2 // indirect
	github.com/Masterminds/goutils v1.1.1 // indirect
	github.com/Masterminds/semver/v3 v3.5.0 // indirect
	github.com/boombuler/barcode v1.1.0 // indirect
	github.com/fsnotify/fsnotify v1.10.1 // indirect
	github.com/go-jose/go-jose/v4 v4.1.6 // indirect
	github.com/go-viper/mapstructure/v2 v2.5.0 // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/huandu/xstrings v1.6.3 // indirect
	github.com/josharian/intern v1.0.0 // indirect
	github.com/mitchellh/copystructure v1.2.0 // indirect
	github.com/mitchellh/reflectwalk v1.0.2 // indirect
	github.com/pelletier/go-toml v1.9.5 // indirect
	github.com/shopspring/decimal v1.6.0 // indirect
	github.com/spf13/cast v1.10.0 // indirect
	golang.org/x/crypto v0.58.0 // indirect
	golang.org/x/image v0.47.0 // indirect
	golang.org/x/sys v0.49.0 // indirect
	golang.org/x/time v0.16.0 // indirect
)
