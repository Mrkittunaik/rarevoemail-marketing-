package main

import (
	"bytes"
	"mime"
	"mime/multipart"
	"net/http"
	"path/filepath"
	"strings"

	"github.com/disintegration/imaging"
	"github.com/rarevo/rarevo/internal/media"
	"github.com/rarevo/rarevo/models"
	"github.com/labstack/echo/v5"
)

const (
	thumbPrefix   = "thumb_"
	thumbnailSize = 250
)

var (
	vectorExts = []string{"svg"}
	imageExts  = []string{"gif", "png", "jpg", "jpeg"}
)

// mediaQueryDefaults is the allow list of filter query params.
var mediaQueryDefaults = map[string]string{
	"page":     "",
	"per_page": "100",
	"query":    "",
	"tag":      "",
}

// mediaView is the admin view for the media gallery page.
type mediaView struct {
	adminView

	Tags     []media.Tag
	Media    []media.Media
	Provider string
	Page     models.PageProps
}

// ViewMedia renders the HTML gallery view for uploaded media.
func (a *App) ViewMedia(c *echo.Context) error {
	res, props, err := a.getMedia(c)
	if err != nil {
		return err
	}

	tags, err := a.core.GetMediaTags(a.cfg.MediaUpload.Provider)
	if err != nil {
		return err
	}

	data := mediaView{
		Tags:      tags,
		adminView: newAdminView(c, a.i18n.T("globals.terms.media"), "", "campaigns.media"),
		Media:     res,
		Provider:  a.cfg.MediaUpload.Provider,
		Page:      props,
	}

	return c.Render(http.StatusOK, "admin-media", data)
}

// ViewMediaFragment renders the header/footer-less media gallery for in iframes (popup dialogs).
func (a *App) ViewMediaFragment(c *echo.Context) error {
	res, props, err := a.getMedia(c)
	if err != nil {
		return err
	}

	tags, err := a.core.GetMediaTags(a.cfg.MediaUpload.Provider)
	if err != nil {
		return err
	}

	data := mediaView{
		Tags:      tags,
		adminView: newAdminView(c, a.i18n.T("globals.terms.media"), "", "campaigns.media"),
		Media:     res,
		Provider:  a.cfg.MediaUpload.Provider,
		Page:      props,
	}

	return c.Render(http.StatusOK, "admin-media-fragment", data)
}

// getMedia queries paginated media items from the DB.
func (a *App) getMedia(c *echo.Context) ([]media.Media, models.PageProps, error) {
	q := makeQuery(c.Request().URL.Query(), mediaQueryDefaults)

	pg := a.pg.NewFromURL(q)
	res, total, err := a.core.QueryMedia(a.cfg.MediaUpload.Provider, a.media, q.Get("query"), q["tag"], pg.Offset, pg.Limit)
	if err != nil {
		return nil, models.PageProps{}, err
	}

	return res, models.NewPageProps(q, total, pg.Page, pg.PerPage), nil
}

// UploadMedia handles media file uploads.
func (a *App) UploadMedia(c *echo.Context) error {
	file, err := c.FormFile("file")
	if err != nil {
		return echo.NewHTTPError(http.StatusBadRequest,
			a.i18n.Ts("globals.messages.invalidFile", "error", err.Error()))
	}

	// Read the file from the HTTP form.
	src, err := file.Open()
	if err != nil {
		return echo.NewHTTPError(http.StatusInternalServerError,
			a.i18n.Ts("globals.messages.errorReadingFile", "error", err.Error()))
	}
	defer src.Close()

	var (
		// Naive check for content type and extension.
		ext         = strings.TrimPrefix(strings.ToLower(filepath.Ext(file.Filename)), ".")
		contentType = file.Header.Get("Content-Type")
	)

	// Validate file extension.
	if !inArray("*", a.cfg.MediaUpload.Extensions) {
		if ok := inArray(ext, a.cfg.MediaUpload.Extensions); !ok {
			return echo.NewHTTPError(http.StatusBadRequest,
				a.i18n.Ts("globals.messages.unsupportedFileType", "type", ext))
		}
	}

	// Sanitize the filename.
	fName := makeFilename(file.Filename)

	// If the filename already exists in the DB, make it unique by adding a random suffix.
	if _, err := a.core.GetMedia(0, "", fName, a.media); err == nil {
		suffix, err := generateRandomString(6)
		if err != nil {
			a.log.Printf("error generating random string: %v", err)
			return echo.NewHTTPError(http.StatusInternalServerError, a.i18n.T("globals.messages.internalError"))
		}

		fName = appendSuffixToFilename(fName, suffix)
	}

	// Upload the file to the media store.
	fName, err = a.media.Put(fName, contentType, src)
	if err != nil {
		a.log.Printf("error uploading file: %v", err)
		return echo.NewHTTPError(http.StatusInternalServerError,
			a.i18n.Ts("globals.messages.errorUploadingFile", "error", err.Error()))
	}

	// This keeps track of whether the file has to be deleted from the DB and the store
	// if any of the subsequent steps fail.
	var (
		cleanUp    = false
		thumbfName = ""
	)
	defer func() {
		if cleanUp {
			a.media.Delete(fName)

			if thumbfName != "" {
				a.media.Delete(thumbfName)
			}
		}
	}()

	// Thumbnail width and height.
	var width, height int

	// Create thumbnail from file for non-vector formats.
	isImage := inArray(ext, imageExts)
	if isImage {
		thumbFile, wi, he, err := processImage(file)
		if err != nil {
			cleanUp = true
			a.log.Printf("error resizing image: %v", err)
			return echo.NewHTTPError(http.StatusInternalServerError,
				a.i18n.Ts("media.errorResizing", "error", err.Error()))
		}
		width = wi
		height = he

		// Upload thumbnail.
		tf, err := a.media.Put(thumbPrefix+fName, contentType, thumbFile)
		if err != nil {
			cleanUp = true
			a.log.Printf("error saving thumbnail: %v", err)
			return echo.NewHTTPError(http.StatusInternalServerError,
				a.i18n.Ts("media.errorSavingThumbnail", "error", err.Error()))
		}
		thumbfName = tf
	}
	if inArray(ext, vectorExts) {
		thumbfName = fName
	}

	// Images have metadata.
	meta := models.JSON{}
	if isImage {
		meta = models.JSON{
			"width":  width,
			"height": height,
		}
	}

	// Insert the media into the DB.
	m, err := a.core.InsertMedia(fName, thumbfName, contentType, meta, c.Request().MultipartForm.Value["tags"], a.cfg.MediaUpload.Provider, a.media)
	if err != nil {
		cleanUp = true
		return err
	}

	return c.JSON(http.StatusOK, okResp{m})
}

// GetAllMedia handles retrieval of uploaded media.
func (a *App) GetAllMedia(c *echo.Context) error {
	var (
		query = c.FormValue("query")

		pg = a.pg.NewFromURL(c.Request().URL.Query())
	)
	// Fetch the media items from the DB.
	res, total, err := a.core.QueryMedia(a.cfg.MediaUpload.Provider, a.media, query, c.Request().URL.Query()["tag"], pg.Offset, pg.Limit)
	if err != nil {
		return err
	}

	out := models.PageResults{
		Results: res,
		PageProps: models.PageProps{
			Total:   total,
			Page:    pg.Page,
			PerPage: pg.PerPage,
		},
	}

	return c.JSON(http.StatusOK, okResp{out})
}

// GetMedia handles retrieval of a media item by ID.
func (a *App) GetMedia(c *echo.Context) error {
	// Fetch the media item from the DB.
	id := getID(c)
	out, err := a.core.GetMedia(id, "", "", a.media)
	if err != nil {
		return err
	}

	return c.JSON(http.StatusOK, okResp{out})
}

// GetMediaTags returns media tags and their counts.
func (a *App) GetMediaTags(c *echo.Context) error {
	out, err := a.core.GetMediaTags(a.cfg.MediaUpload.Provider)
	if err != nil {
		return err
	}

	return c.JSON(http.StatusOK, okResp{out})
}

// UpdateMedia updates a media item's tags.
func (a *App) UpdateMedia(c *echo.Context) error {
	var m struct {
		Tags []string `json:"tags"`
	}

	if err := c.Bind(&m); err != nil {
		return err
	}

	out, err := a.core.UpdateMedia(getID(c), m.Tags, a.media)
	if err != nil {
		return err
	}

	return c.JSON(http.StatusOK, okResp{out})
}

// DeleteMedia handles deletion of uploaded media.
func (a *App) DeleteMedia(c *echo.Context) error {

	// Delete the media from the DB. The query returns the filename.
	id := getID(c)
	fname, err := a.core.DeleteMedia(id)
	if err != nil {
		return err
	}

	// Delete the files from the media store.
	a.media.Delete(fname)
	a.media.Delete(thumbPrefix + fname)

	return c.JSON(http.StatusOK, okResp{true})
}

// ServeS3Media serves media files stored in S3 when the public URL is a relative path.
func (a *App) ServeS3Media(c *echo.Context) error {
	key := c.Param("filepath")
	if key == "" {
		return echo.NewHTTPError(http.StatusBadRequest, "missing media file path")
	}

	b, err := a.media.GetBlob(key)
	if err != nil {
		a.log.Printf("error fetching media from s3 %s: %v", key, err)
		return echo.NewHTTPError(http.StatusInternalServerError, "error fetching media")
	}

	// Detect content type from file bites.
	ctype := http.DetectContentType(b)
	switch ctype {
	// Images like SVGs will be detected as text/plain, so for those types, fall back
	// to using the simple file extension check.
	case "text/plain; charset=utf-8", "text/xml; charset=utf-8", "application/octet-stream":
		if typ := mime.TypeByExtension(filepath.Ext(key)); typ != "" {
			ctype = typ
		}
	}

	return c.Stream(http.StatusOK, ctype, bytes.NewReader(b))
}

// processImage reads the image file and returns thumbnail bytes and
// the original image's width, and height.
func processImage(file *multipart.FileHeader) (*bytes.Reader, int, int, error) {
	src, err := file.Open()
	if err != nil {
		return nil, 0, 0, err
	}
	defer src.Close()

	img, err := imaging.Decode(src)
	if err != nil {
		return nil, 0, 0, err
	}

	// Encode the image into a byte slice as PNG.
	var (
		thumb = imaging.Resize(img, thumbnailSize, 0, imaging.Lanczos)
		out   bytes.Buffer
	)
	if err := imaging.Encode(&out, thumb, imaging.PNG); err != nil {
		return nil, 0, 0, err
	}

	b := img.Bounds().Max
	return bytes.NewReader(out.Bytes()), b.X, b.Y, nil
}
