package main

import (
	"html/template"
	"net/http"
	"regexp"
	"strconv"
	"strings"

	"github.com/rarevo/rarevo/models"
	"github.com/labstack/echo/v5"
)

const (
	// tplTag is the template tag that should be present in a template
	// as the placeholder for campaign bodies.
	tplTag = `{{ template "content" . }}`

	dummyTpl = `
		<p>Hi there</p>
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis et elit ac elit sollicitudin condimentum non a magna. Sed tempor mauris in facilisis vehicula. Aenean nisl urna, accumsan ac tincidunt vitae, interdum cursus massa. Interdum et malesuada fames ac ante ipsum primis in faucibus. Aliquam varius turpis et turpis lacinia placerat. Aenean id ligula a orci lacinia blandit at eu felis. Phasellus vel lobortis lacus. Suspendisse leo elit, luctus sed erat ut, venenatis fermentum ipsum. Donec bibendum neque quis.</p>

		<h3>Sub heading</h3>
		<p>Nam luctus dui non placerat mattis. Morbi non accumsan orci, vel interdum urna. Duis faucibus id nunc ut euismod. Curabitur et eros id erat feugiat fringilla in eget neque. Aliquam accumsan cursus eros sed faucibus.</p>

		<p>Here is a link to <a href="https://rarevo.com" target="_blank">rarevo</a>.</p>`
)

var (
	regexpTplTag = regexp.MustCompile(`{{(\s+)?template\s+?"content"(\s+)?\.(\s+)?}}`)

	// templatesQueryDefaults is the allow list of filter query params.
	templatesQueryDefaults = map[string]string{
		"type":     "",
		"query":    "",
		"order_by": models.FieldCreatedAt,
		"order":    models.OrderAsc,
	}
)

// templatesView is the admin page view for the templates list page.
type templatesView struct {
	adminView

	Templates []models.Template
	Page      models.PageProps
	Type      string
}

// templateView is the admin page view for creating/editing a single template.
type templateView struct {
	adminView

	IsNew    bool
	Template models.Template
}

// ViewTemplates renders the HTML list view for templates.
func (a *App) ViewTemplates(c *echo.Context) error {
	q := makeQuery(c.Request().URL.Query(), templatesQueryDefaults)
	typ := q.Get("type")

	out, err := a.core.GetTemplates(q.Get("query"), typ, true, q.Get("order_by"), q.Get("order"))
	if err != nil {
		return err
	}

	data := templatesView{
		adminView: newAdminView(c, a.i18n.T("globals.terms.templates"), "", "campaigns.templates"),
		Templates: out,
		Page:      models.NewPageProps(q, len(out), 1, 0),
		Type:      typ,
	}

	return c.Render(http.StatusOK, "admin-templates", data)
}

// ViewNewTemplate renders the new template page.
func (a *App) ViewNewTemplate(c *echo.Context) error {
	data := templateView{
		adminView: newAdminView(c, a.i18n.T("templates.newTemplate")+" / "+a.i18n.T("globals.terms.templates"), "", "campaigns.templates"),
		IsNew:     true,
		Template:  models.Template{Type: models.TemplateTypeCampaign},
	}

	return c.Render(http.StatusOK, "admin-template", data)
}

// ViewTemplate renders the single-page editor for an existing template.
func (a *App) ViewTemplate(c *echo.Context) error {
	id := getID(c)
	out, err := a.core.GetTemplate(id, false)
	if err != nil {
		return err
	}

	data := templateView{
		adminView: newAdminView(c, out.Name+" / "+a.i18n.T("globals.terms.templates"), "", "campaigns.templates"),
		Template:  out,
	}

	return c.Render(http.StatusOK, "admin-template", data)
}

// GetTemplate handles the retrieval of a template
func (a *App) GetTemplate(c *echo.Context) error {
	// If no_body is true, blank out the body of the template from the response.
	noBody, _ := strconv.ParseBool(c.QueryParam("no_body"))

	// Get the template from the DB.
	id := getID(c)
	out, err := a.core.GetTemplate(id, noBody)
	if err != nil {
		return err
	}

	return c.JSON(http.StatusOK, okResp{out})
}

// GetTemplates handles retrieval of templates.
func (a *App) GetTemplates(c *echo.Context) error {
	// If no_body is true, blank out the body of the template from the response.
	noBody, _ := strconv.ParseBool(c.QueryParam("no_body"))

	// Fetch templates from the DB.
	out, err := a.core.GetTemplates(c.QueryParam("query"), "", noBody, c.QueryParam("order_by"), c.QueryParam("order"))
	if err != nil {
		return err
	}

	return c.JSON(http.StatusOK, okResp{out})
}

// PreviewTemplate renders the HTML preview of a template in the DB.
func (a *App) PreviewTemplate(c *echo.Context) error {
	// Fetch one template from the DB.
	id := getID(c)
	tpl, err := a.core.GetTemplate(id, false)
	if err != nil {
		return err
	}

	// Render the template.
	out, err := a.previewTemplate(tpl)
	if err != nil {
		return err
	}

	return renderSandboxedHTML(c, string(out))
}

// PreviewTemplateBody renders the HTML preview of a template given its type and body.
func (a *App) PreviewTemplateBody(c *echo.Context) error {
	tpl := models.Template{
		Type: c.FormValue("template_type"),
		Body: c.FormValue("body"),
	}

	// Body is posted with the request.
	if tpl.Type == "" {
		tpl.Type = models.TemplateTypeCampaign
	}

	if tpl.Type == models.TemplateTypeCampaign && !regexpTplTag.MatchString(tpl.Body) {
		return echo.NewHTTPError(http.StatusBadRequest,
			a.i18n.Ts("templates.placeholderHelp", "placeholder", tplTag))
	}

	// Render the template.
	out, err := a.previewTemplate(tpl)
	if err != nil {
		return err
	}

	return renderSandboxedHTML(c, string(out))
}

// CreateTemplate handles template creation.
func (a *App) CreateTemplate(c *echo.Context) error {
	var o models.Template
	if err := c.Bind(&o); err != nil {
		return err
	}
	if o.Type != models.TemplateTypeCampaign && o.Type != models.TemplateTypeCampaignVisual && o.Type != models.TemplateTypeTx {
		return echo.NewHTTPError(http.StatusBadRequest, a.i18n.Ts("globals.messages.invalidFields", "name", "type"))
	}

	if err := a.validateTemplate(o); err != nil {
		return err
	}

	// Subject is only relevant for fixed tx templates. For campaigns,
	// the subject changes per campaign and is on models.Campaign.
	var funcs template.FuncMap
	if o.Type == models.TemplateTypeCampaign || o.Type == models.TemplateTypeCampaignVisual {
		o.Subject = ""
		funcs = a.manager.TemplateFuncs(nil)
	} else {
		funcs = a.manager.GenericTemplateFuncs()
	}

	// Compile the template and validate.
	if err := o.Compile(funcs); err != nil {
		return echo.NewHTTPError(http.StatusBadRequest, err.Error())
	}

	// Create the template the in the DB.
	out, err := a.core.CreateTemplate(o.Name, o.Type, o.Subject, []byte(o.Body), o.BodySource)
	if err != nil {
		return err
	}

	// If it's a transactional template, cache it in the manager
	// to be used for arbitrary incoming tx message pushes.
	if o.Type == models.TemplateTypeTx {
		a.manager.CacheTpl(out.ID, &o)
	}

	return c.JSON(http.StatusOK, okResp{out})
}

// UpdateTemplate handles template modification.
func (a *App) UpdateTemplate(c *echo.Context) error {
	var o models.Template
	if err := c.Bind(&o); err != nil {
		return err
	}
	if err := a.validateTemplate(o); err != nil {
		return err
	}

	// Subject is only relevant for fixed tx templates. For campaigns,
	// the subject changes per campaign and is on models.Campaign.
	var funcs template.FuncMap
	if o.Type == models.TemplateTypeCampaign || o.Type == models.TemplateTypeCampaignVisual {
		o.Subject = ""
		funcs = a.manager.TemplateFuncs(nil)
	} else {
		funcs = a.manager.GenericTemplateFuncs()
	}

	// Compile the template and validate.
	if err := o.Compile(funcs); err != nil {
		return echo.NewHTTPError(http.StatusBadRequest, err.Error())
	}

	// Update the template in the DB.
	id := getID(c)
	out, err := a.core.UpdateTemplate(id, o.Name, o.Subject, []byte(o.Body), o.BodySource)
	if err != nil {
		return err
	}

	// If it's a transactional template, cache it.
	if out.Type == models.TemplateTypeTx {
		a.manager.CacheTpl(out.ID, &o)
	}

	return c.JSON(http.StatusOK, okResp{out})

}

// TemplateSetDefault handles template modification.
func (a *App) TemplateSetDefault(c *echo.Context) error {
	// Update the template in the DB.
	id := getID(c)
	if err := a.core.SetDefaultTemplate(id); err != nil {
		return err
	}

	return a.GetTemplates(c)
}

// DeleteTemplate handles template deletion.
func (a *App) DeleteTemplate(c *echo.Context) error {
	// Delete the template from the DB.
	id := getID(c)
	if err := a.core.DeleteTemplate(id); err != nil {
		return err
	}

	// Delete cached in-memory template.
	a.manager.DeleteTpl(id)

	return c.JSON(http.StatusOK, okResp{true})
}

// compileTemplate validates template fields.
func (a *App) validateTemplate(o models.Template) error {
	if !strHasLen(o.Name, 1, stdInputMaxLen) {
		return echo.NewHTTPError(http.StatusBadRequest, a.i18n.T("campaigns.fieldInvalidName"))
	}

	if o.Type == models.TemplateTypeCampaign && !regexpTplTag.MatchString(o.Body) {
		return echo.NewHTTPError(http.StatusBadRequest,
			a.i18n.Ts("templates.placeholderHelp", "placeholder", tplTag))
	}

	if o.Type == models.TemplateTypeTx && strings.TrimSpace(o.Subject) == "" {
		return echo.NewHTTPError(http.StatusBadRequest,
			a.i18n.Ts("globals.messages.missingFields", "name", "subject"))
	}

	return nil
}

// previewTemplate renders the HTML preview of a template.
func (a *App) previewTemplate(tpl models.Template) ([]byte, error) {
	var out []byte
	if tpl.Type == models.TemplateTypeCampaign || tpl.Type == models.TemplateTypeCampaignVisual {
		camp := models.Campaign{
			UUID:         dummyUUID,
			Name:         a.i18n.T("templates.dummyName"),
			Subject:      a.i18n.T("templates.dummySubject"),
			FromEmail:    "dummy-campaign@rarevo.com",
			TemplateBody: tpl.Body,
			Body:         dummyTpl,
		}

		if err := camp.CompileTemplate(a.manager.TemplateFuncs(&camp, models.CampPreview)); err != nil {
			return nil, echo.NewHTTPError(http.StatusBadRequest,
				a.i18n.Ts("templates.errorCompiling", "error", err.Error()))
		}

		// Render the message body.
		msg, err := a.manager.NewCampaignMessage(&camp, dummySubscriber)
		if err != nil {
			return nil, echo.NewHTTPError(http.StatusBadRequest,
				a.i18n.Ts("templates.errorRendering", "error", err.Error()))
		}
		out = msg.Body()
	} else {
		// Compile transactional template.
		funcs := a.manager.GenericTemplateFuncs(models.CampPreview)
		if err := tpl.Compile(funcs); err != nil {
			return nil, echo.NewHTTPError(http.StatusBadRequest, err.Error())
		}

		m := models.TxMessage{
			Subject: tpl.Subject,
		}

		// Render the message.
		if err := m.Render(dummySubscriber, &tpl, funcs); err != nil {
			return nil, echo.NewHTTPError(http.StatusBadRequest, err.Error())
		}
		out = m.Body
	}

	return out, nil
}
