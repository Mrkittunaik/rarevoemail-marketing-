package models

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"html/template"
	"strings"
	txttpl "text/template"
	"time"

	"github.com/jmoiron/sqlx"
	"github.com/jmoiron/sqlx/types"
	"github.com/lib/pq"
	null "gopkg.in/volatiletech/null.v6"
)

const (
	CampaignStatusDraft         = "draft"
	CampaignStatusScheduled     = "scheduled"
	CampaignStatusRunning       = "running"
	CampaignStatusPaused        = "paused"
	CampaignStatusFinished      = "finished"
	CampaignStatusCancelled     = "cancelled"
	CampaignTypeRegular         = "regular"
	CampaignTypeOptin           = "optin"
	CampaignContentTypeRichtext = "richtext"
	CampaignContentTypeHTML     = "html"
	CampaignContentTypeMarkdown = "markdown"
	CampaignContentTypePlain    = "plain"
	CampaignContentTypeVisual   = "visual"
)

// CampOpt is a campaign manager option type.
type CampOpt int

const (
	CampPreview CampOpt = iota
)

// Campaigns represents a slice of Campaigns.
type Campaigns []Campaign

// CampaignList is a minimal representation of a campaign's associated list,
// parsed from the raw Lists JSON for use in HTML views.
type CampaignList struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
}

// CampaignMedia is a minimal representation of a campaign's attached media,
// parsed from the raw Media JSON for use in HTML views.
type CampaignMedia struct {
	ID        int       `json:"id"`
	Filename  string    `json:"filename"`
	URL       string    `json:"url"`
	ThumbURL  string    `json:"thumb_url"`
	CreatedAt null.Time `json:"created_at"`
}

// Campaign represents an e-mail campaign.
type Campaign struct {
	Base
	CampaignMeta

	UUID              string          `db:"uuid" json:"uuid"`
	Type              string          `db:"type" json:"type"`
	Name              string          `db:"name" json:"name"`
	Subject           string          `db:"subject" json:"subject"`
	FromEmail         string          `db:"from_email" json:"from_email"`
	Body              string          `db:"body" json:"body"`
	BodySource        null.String     `db:"body_source" json:"body_source"`
	AltBody           null.String     `db:"altbody" json:"altbody"`
	SendAt            null.Time       `db:"send_at" json:"send_at"`
	Status            string          `db:"status" json:"status"`
	ContentType       string          `db:"content_type" json:"content_type"`
	Tags              pq.StringArray  `db:"tags" json:"tags"`
	Headers           Headers         `db:"headers" json:"headers"`
	Attribs           JSON            `db:"attribs" json:"attribs"`
	TemplateID        null.Int        `db:"template_id" json:"template_id"`
	Messenger         string          `db:"messenger" json:"messenger"`
	Archive           bool            `db:"archive" json:"archive"`
	ArchiveSlug       null.String     `db:"archive_slug" json:"archive_slug"`
	ArchiveTemplateID null.Int        `db:"archive_template_id" json:"archive_template_id"`
	ArchiveMeta       json.RawMessage `db:"archive_meta" json:"archive_meta"`
	LastSubscriberID  int             `db:"last_subscriber_id" json:"-"`

	// TemplateBody is joined in from templates by the next-campaigns query.
	TemplateBody        string       `db:"template_body" json:"-"`
	ArchiveTemplateBody string       `db:"archive_template_body" json:"-"`
	Tpl                 *tplRenderer `json:"-"`
	SubjectTpl          *tplRenderer `json:"-"`
	FromEmailTpl        *tplRenderer `json:"-"`
	AltBodyTpl          *tplRenderer `json:"-"`

	// HeaderTpls holds optionally {{ templated }} campaign headers.
	HeaderTpls []map[string]*tplRenderer `json:"-"`

	// List of media (attachment) IDs obtained from the next-campaign query
	// while sending a campaign.
	MediaIDs pq.Int64Array `json:"-" db:"media_id"`

	// Fetched bodies of the attachments.
	Attachments []Attachment `json:"-" db:"-"`

	// Pseudofield for getting the total number of subscribers
	// in searches and queries.
	Total int `db:"total" json:"-"`
}

// CampaignMeta contains fields tracking a campaign's progress.
type CampaignMeta struct {
	CampaignID int `db:"campaign_id" json:"-"`
	Views      int `db:"views" json:"views"`
	Clicks     int `db:"clicks" json:"clicks"`
	Bounces    int `db:"bounces" json:"bounces"`

	// This is a list of {list_id, name} pairs unlike Subscriber.Lists[]
	// because lists can be deleted after a campaign is finished, resulting
	// in null lists data to be returned. For that reason, campaign_lists maintains
	// campaign-list associations with a historical record of id + name that persist
	// even after a list is deleted.
	Lists types.JSONText `db:"lists" json:"lists"`
	Media types.JSONText `db:"media" json:"media"`

	StartedAt null.Time `db:"started_at" json:"started_at"`
	ToSend    int       `db:"to_send" json:"to_send"`
	Sent      int       `db:"sent" json:"sent"`
}

// CampaignActivity summarizes a subscriber's activity in a campaign selection.
type CampaignActivity struct {
	ID           int       `db:"id"`
	Email        string    `db:"email"`
	Name         string    `db:"name"`
	Views        int       `db:"views"`
	Clicks       int       `db:"clicks"`
	LastActivity time.Time `db:"last_activity"`
	Total        int       `db:"total"`
}

// CampaignActivityEvent is a single tracked open or click.
type CampaignActivityEvent struct {
	CampaignID      int       `db:"campaign_id"`
	CampaignSubject string    `db:"campaign_subject"`
	Campaign        string    `db:"campaign"`
	Type            string    `db:"type"`
	URL             string    `db:"url"`
	CreatedAt       time.Time `db:"created_at"`
	Total           int       `db:"total"`
}

// ParsedLists unmarshals the campaign's raw Lists JSON into a slice for
// rendering in HTML views.
func (c Campaign) ParsedLists() []CampaignList {
	if len(c.Lists) == 0 {
		return nil
	}

	var out []CampaignList
	if err := json.Unmarshal(c.Lists, &out); err != nil {
		return nil
	}

	return out
}

// ParsedMedia unmarshals the campaign's raw Media JSON into a slice for
// rendering in HTML views.
func (c Campaign) ParsedMedia() []CampaignMedia {
	if len(c.Media) == 0 {
		return nil
	}

	var out []CampaignMedia
	if err := json.Unmarshal(c.Media, &out); err != nil {
		return nil
	}

	return out
}

// GetIDs returns the list of campaign IDs.
func (camps Campaigns) GetIDs() []int {
	IDs := make([]int, len(camps))
	for i, c := range camps {
		IDs[i] = c.ID
	}

	return IDs
}

// LoadStats lazy loads campaign stats onto a list of campaigns.
func (camps Campaigns) LoadStats(stmt *sqlx.Stmt) error {
	var meta []CampaignMeta
	if err := stmt.Select(&meta, pq.Array(camps.GetIDs())); err != nil {
		return err
	}

	if len(camps) != len(meta) {
		return errors.New("campaign stats count does not match")
	}

	for i, c := range meta {
		if c.CampaignID == camps[i].ID {
			camps[i].Lists = c.Lists
			camps[i].Views = c.Views
			camps[i].Clicks = c.Clicks
			camps[i].Bounces = c.Bounces
			camps[i].Media = c.Media
		}
	}

	return nil
}

// CompileTemplate compiles a campaign body template into its base
// template and sets the resultant template to Campaign.Tpl.
func (c *Campaign) CompileTemplate(f template.FuncMap) error {
	var err error
	c.SubjectTpl, err = compileTxtTpl("subject", c.Subject, f)
	if err != nil {
		return err
	}

	c.FromEmailTpl, err = compileTxtTpl("from", c.FromEmail, f)
	if err != nil {
		return err
	}

	// Compile the base template.
	body := c.TemplateBody

	if body == "" || c.ContentType == CampaignContentTypeVisual {
		body = `{{ template "content" . }}`
	}

	for _, r := range regTplFuncs {
		body = r.regExp.ReplaceAllString(body, r.replace)
	}

	baseTPL, err := template.New(BaseTpl).Funcs(f).Parse(body)
	if err != nil {
		return fmt.Errorf("error compiling base template: %v", err)
	}

	// If the format is markdown, convert Markdown to HTML.
	if c.ContentType == CampaignContentTypeMarkdown {
		var b bytes.Buffer
		if err := markdown.Convert([]byte(c.Body), &b); err != nil {
			return err
		}
		body = b.String()
	} else {
		body = c.Body
	}

	// Compile the campaign message.
	for _, r := range regTplFuncs {
		body = r.regExp.ReplaceAllString(body, r.replace)
	}

	msgTpl, err := template.New(ContentTpl).Funcs(f).Parse(body)
	if err != nil {
		return fmt.Errorf("error compiling message: %v", err)
	}

	out, err := baseTPL.AddParseTree(ContentTpl, msgTpl.Tree)
	if err != nil {
		return fmt.Errorf("error inserting child template: %v", err)
	}
	c.Tpl = &tplRenderer{out}

	if HasTplExpr(c.AltBody.String) {
		b := c.AltBody.String
		for _, r := range regTplFuncs {
			b = r.regExp.ReplaceAllString(b, r.replace)
		}
		bTpl, err := template.New(ContentTpl).Funcs(f).Parse(b)
		if err != nil {
			return fmt.Errorf("error compiling alt plaintext message: %v", err)
		}
		c.AltBodyTpl = &tplRenderer{bTpl}
	}

	// Rebuild header templates in case the campaign is being recompiled.
	c.HeaderTpls = nil
	for i, set := range c.Headers {
		for hdr, val := range set {
			tpl, err := compileTxtTpl(fmt.Sprintf("header %q", hdr), val, f)
			if err != nil {
				return err
			}
			if tpl == nil {
				continue
			}

			if c.HeaderTpls == nil {
				c.HeaderTpls = make([]map[string]*tplRenderer, len(c.Headers))
			}
			if c.HeaderTpls[i] == nil {
				c.HeaderTpls[i] = make(map[string]*tplRenderer)
			}
			c.HeaderTpls[i][hdr] = tpl
		}
	}

	return nil
}

func compileTxtTpl(label, val string, f template.FuncMap) (*tplRenderer, error) {
	if !HasTplExpr(val) {
		return nil, nil
	}

	for _, r := range regTplFuncs {
		val = r.regExp.ReplaceAllString(val, r.replace)
	}

	tpl, err := txttpl.New(ContentTpl).Funcs(f).Parse(val)
	if err != nil {
		return nil, fmt.Errorf("error compiling %s: %v", label, err)
	}

	return &tplRenderer{tpl}, nil
}

// ConvertContent converts a campaign's body from one format to another,
// for example, Markdown to HTML.
func (c *Campaign) ConvertContent(from, to string) (string, error) {
	body := c.Body
	for _, r := range regTplFuncs {
		body = r.regExp.ReplaceAllString(body, r.replace)
	}

	// If the format is markdown, convert Markdown to HTML.
	var out string
	if from == CampaignContentTypeMarkdown &&
		(to == CampaignContentTypeHTML || to == CampaignContentTypeRichtext) {
		var b bytes.Buffer
		if err := markdown.Convert([]byte(c.Body), &b); err != nil {
			return out, err
		}
		out = b.String()
	} else {
		return out, errors.New("unknown formats to convert")
	}

	return out, nil
}

// HasTplExpr checks whether a given string has a Go template expression with {{ and  }}.
func HasTplExpr(s string) bool {
	_, after, ok := strings.Cut(s, "{{")
	return ok && strings.Contains(after, "}}")
}
