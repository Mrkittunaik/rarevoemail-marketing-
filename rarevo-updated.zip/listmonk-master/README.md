<p align="center"><a href="https://rarevo.com"><img src="static/public/static/logo.svg" alt="Rarevo" height="40"></a></p>

# Rarevo

Rarevo is Rarevo's self-hosted newsletter and mailing list platform. It runs as a single binary and stores its data in PostgreSQL.

## Run with Docker

```shell
docker compose up -d
```
Then open `http://localhost:9000`.

## Run the binary

```shell
./rarevo --new-config      # generate config.toml, then edit it
./rarevo --install         # set up the PostgreSQL database (use --upgrade for existing DBs)
./rarevo                   # open http://localhost:9000
```

## Build from source

Requires Go, Node.js and Bun.

```shell
make dist
```

## License

Rarevo is released under the GNU AGPL v3. See [LICENSE](LICENSE) and [NOTICE](NOTICE).
Copyright (c) 2026 Rarevo.
