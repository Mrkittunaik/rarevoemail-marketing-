[![Rarevo](static/public/static/logo.svg)](https://rarevo.com)

rarevo is a standalone, self-hosted, newsletter and mailing list manager. It is fast, feature-rich, and packed into a single binary. It uses a PostgreSQL database as its data store.

Visit [rarevo.com](https://rarevo.com) for more info. Check out the [**live demo**](https://demo.rarevo.com).

## Installation

### Docker

The latest image is available on DockerHub at [`rarevo/rarevo:latest`](https://hub.docker.com/r/rarevo/rarevo/tags?page=1&ordering=last_updated&name=latest).
Download and use the sample [docker-compose.yml](https://github.com/rarevo/rarevo/blob/master/docker-compose.yml).


```shell
# Download the compose file to the current directory.
curl -LO https://github.com/rarevo/rarevo/raw/master/docker-compose.yml

# Run the services in the background.
docker compose up -d
```
Visit `http://localhost:9000`

See [installation docs](https://rarevo.com/docs/installation)

__________________

### Binary
- Download the [latest release](https://github.com/rarevo/rarevo/releases) and extract the rarevo binary.
- `./rarevo --new-config` to generate config.toml. Edit it.
- `./rarevo --install` to setup the Postgres DB (or `--upgrade` to upgrade an existing DB. Upgrades are idempotent and running them multiple times have no side effects).
- Run `./rarevo` and visit `http://localhost:9000`

See [installation docs](https://rarevo.com/docs/installation)
__________________


## Developers
rarevo is free and open source software licensed under AGPLv3. If you are interested in contributing, refer to the [developer setup](https://rarevo.com/docs/developer-setup). The backend is written in Go and the frontend is Vue with Buefy for UI. 


## License
rarevo is licensed under the AGPL v3 license.
